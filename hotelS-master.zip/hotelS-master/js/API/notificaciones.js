//Notificaciones
function pgAlert(tit,com){
	navigator.notification.alert(com, null, tit, "Confirmado");
}